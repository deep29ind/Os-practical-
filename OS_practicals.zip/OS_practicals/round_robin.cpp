#include <iostream>
#include <queue>
#include <vector>
using namespace std;

struct Process
{
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int completion_time;
    int turn_around_time;
    int waiting_time;
};

void findRoundRobin(Process arr[], int n, int time_quantum)
{
    queue<int> q;
    vector<bool> in_queue(n, false); // Track if a process is already in the queue
    int time = 0;
    int completed = 0;

    // Add processes that have arrived initially
    for (int i = 0; i < n; i++)
    {
        arr[i].remaining_time = arr[i].burst_time;
    }

    // Push the first process into the queue
    q.push(0);
    in_queue[0] = true;

    while (!q.empty() && completed < n)
    {
        int i = q.front();
        q.pop();
        in_queue[i] = false;

        if (arr[i].remaining_time > time_quantum)
        {
            // Process executes for 'time_quantum' and is then added back to the queue
            time += time_quantum;
            arr[i].remaining_time -= time_quantum;

            // Push any new arriving processes into the queue
            for (int j = 0; j < n; j++)
            {
                if (j != i && arr[j].arrival_time <= time && arr[j].remaining_time > 0 && !in_queue[j])
                {
                    q.push(j);
                    in_queue[j] = true;
                }
            }

            q.push(i); // Push the current process back into the queue
            in_queue[i] = true;
        }
        else
        {
            // Process completes
            time += arr[i].remaining_time;
            arr[i].completion_time = time;
            arr[i].turn_around_time = arr[i].completion_time - arr[i].arrival_time;
            arr[i].waiting_time = arr[i].turn_around_time - arr[i].burst_time;
            arr[i].remaining_time = 0;
            completed++;

            // Push any newly arriving processes into the queue
            for (int j = 0; j < n; j++)
            {
                if (j != i && arr[j].arrival_time <= time && arr[j].remaining_time > 0 && !in_queue[j])
                {
                    q.push(j);
                    in_queue[j] = true;
                }
            }
        }
    }
}

void display(Process arr[], int n)
{
    int count = 0;
    float wt = 0;
    float tat = 0;
    cout << "\t\t\t\tROUND ROBIN TABLE" << endl;
    cout << "Process ID   Arrival Time   Burst Time  Completion Time  Turn Around Time  Waiting Time" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << arr[i].pid << "\t\t" << arr[i].arrival_time << "\t\t" << arr[i].burst_time << "\t\t" << arr[i].completion_time << "\t\t" << arr[i].turn_around_time << "\t\t" << arr[i].waiting_time << endl;
        count++;
        wt += arr[i].waiting_time;
        tat += arr[i].turn_around_time;
    }
    cout << "The average waiting time is " << (wt / count) << endl;
    cout << "The average turn around time is " << (tat / count) << endl;
}

int main()
{
    int n, time_quantum;
    cout << "Enter the number of processes: ";
    cin >> n;
    cout << "Enter the time quantum: ";
    cin >> time_quantum;

    Process arr[n];
    for (int i = 0; i < n; i++)
    {
        cout << "Enter the Process ID, Arrival Time and Burst Time: ";
        cin >> arr[i].pid >> arr[i].arrival_time >> arr[i].burst_time;
    }

    findRoundRobin(arr, n, time_quantum);
    display(arr, n);
    return 0;
}