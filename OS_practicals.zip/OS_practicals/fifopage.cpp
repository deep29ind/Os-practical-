#include <bits/stdc++.h>
using namespace std;
bool isfull(queue<int> q, int m)
{
    if (q.size() == m)
    {
        return true;
    }
    return false;
}
bool find(queue<int> q, int target)
{
    while (!q.empty())
    {
        int a = q.front();
        q.pop();
        if (a == target)
        {
            return true;
        }
    }
    return false;
}
void display(queue<int> q)
{
    while (!q.empty())
    {
        int a = q.front();
        q.pop();
        cout << a << " ";
    }
    cout << endl;
}
int FIFO(queue<int> q, int m, int n, vector<int> v)
{
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        if (!find(q, v[i]))
        {
            count++;
            if (isfull(q, m))
            {
                q.pop();
            }
            q.push(v[i]);
        }
    }
    return count;
}
int main()
{
    int n;
    cout << "Enter the number of pages " << endl;
    cin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    int m;
    cout << "Enter the frame size" << endl;
    cin >> m;
    queue<int> q;
    cout << FIFO(q, m, n, v);
    return 0;
}