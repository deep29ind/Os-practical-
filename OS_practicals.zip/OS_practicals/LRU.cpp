#include <bits/stdc++.h>
using namespace std;

// Check if the page exists in the frame
bool find(const vector<int> &frame, int target)
{
    return find(frame.begin(), frame.end(), target) != frame.end();
}

// Find the least recently used page to replace
int findLRUIndex(const vector<int> &frame, const vector<int> &recentUse)
{
    int lru = INT_MAX, index = -1;
    for (int i = 0; i < frame.size(); i++)
    {
        if (recentUse[i] < lru)
        {
            lru = recentUse[i];
            index = i;
        }
    }
    return index;
}

// LRU Page Replacement Algorithm
int LRU(const vector<int> &pages, int m, int n)
{
    vector<int> frame;     // Stores the current pages in memory
    vector<int> recentUse; // Tracks the recent usage of each page in the frame
    int pageFaults = 0;

    for (int i = 0; i < n; i++)
    {
        // Check if the page is already in the frame
        if (find(frame, pages[i]))
        {
            // Update the recent usage of the page
            for (int j = 0; j < frame.size(); j++)
            {
                if (frame[j] == pages[i])
                {
                    recentUse[j] = i;
                    break;
                }
            }
            continue;
        }

        // Page fault occurs
        pageFaults++;

        // If the frame is full, replace the least recently used page
        if (frame.size() == m)
        {
            int lruIndex = findLRUIndex(frame, recentUse);
            frame[lruIndex] = pages[i];
            recentUse[lruIndex] = i;
        }
        else
        {
            // Add the page to the frame
            frame.push_back(pages[i]);
            recentUse.push_back(i);
        }
    }

    return pageFaults;
}

int main()
{
    int n;
    cout << "Enter the number of pages:" << endl;
    cin >> n;
    vector<int> v(n);
    cout << "Enter the pages:" << endl;
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    int m;
    cout << "Enter the frame size:" << endl;
    cin >> m;

    cout << "Page Faults using LRU Page Replacement: " << LRU(v, m, n) << endl;
    return 0;
}