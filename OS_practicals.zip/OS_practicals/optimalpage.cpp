#include <bits/stdc++.h>
using namespace std;

// Check if the page exists in the frame
bool find(const vector<int>& frame, int target)
{
    return find(frame.begin(), frame.end(), target) != frame.end();
}

// Find the page to replace based on future references
int findReplacementIndex(const vector<int>& frame, const vector<int>& pages, int currentIndex)
{
    int farthest = -1, index = -1;
    for (int i = 0; i < frame.size(); i++)
    {
        int nextUse = INT_MAX;
        for (int j = currentIndex + 1; j < pages.size(); j++)
        {
            if (pages[j] == frame[i])
            {
                nextUse = j;
                break;
            }
        }
        if (nextUse > farthest)
        {
            farthest = nextUse;
            index = i;
        }
    }
    return index;
}

// Optimal Page Replacement Algorithm
int Optimal(const vector<int>& pages, int m, int n)
{
    vector<int> frame; // Stores the current pages in memory
    int pageFaults = 0;

    for (int i = 0; i < n; i++)
    {
        // Check if the page is already in the frame
        if (find(frame, pages[i]))
        {
            continue;
        }

        // Page fault occurs
        pageFaults++;

        // If the frame is full, replace a page
        if (frame.size() == m)
        {
            int replacementIndex = findReplacementIndex(frame, pages, i);
            frame[replacementIndex] = pages[i];
        }
        else
        {
            // Add the page to the frame
            frame.push_back(pages[i]);
        }
    }
    return pageFaults;
}

int main()
{
    int n;
    cout << "Enter the number of pages:" << endl;
    cin >> n;
    vector<int> v(n);
    cout << "Enter the pages:" << endl;
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    int m;
    cout << "Enter the frame size:" << endl;
    cin >> m;

    cout << "Page Faults using Optimal Page Replacement: " << Optimal(v, m, n) << endl;
    return 0;
}