#include <bits/stdc++.h>
using namespace std;

void next_fit(vector<int> v1, vector<int> v2)
{
    map<int, int> mp;
    int n = v1.size();
    int m = v2.size();
    int last_allocated = 0;

    for (int i = 0; i < n; i++)
    {
        bool allocated = false;
        for (int j = 0; j < m; j++)
        {
            int index = (last_allocated + j) % m; // wrap around to implement next fit
            if (v1[i] <= v2[index])
            {
                mp[v1[i]] = v2[index];
                v2[index] -= v1[i];               // decrease available memory in the block
                last_allocated = (index + 1) % m; // move to the next block after allocation
                allocated = true;
                break;
            }
        }
        if (!allocated)
        {
            mp[v1[i]] = -1; // indicates no memory block was found
        }
    }

    cout << "\tNEXT FIT ALGORITHM" << endl;
    cout << "PROCESS SIZE" << setw(20) << "MEMORY ALLOCATED" << endl;
    for (auto it : mp)
    {
        if (it.second == -1)
            cout << it.first << setw(20) << "Not Allocated" << endl;
        else
            cout << it.first << setw(20) << it.second << endl;
    }
}

int main()
{
    int n;
    cout << "Enter the number of processes: ";
    cin >> n;
    vector<int> v1(n);

    cout << "Enter the process sizes: ";
    for (int i = 0; i < n; i++)
    {
        cin >> v1[i];
    }

    int m;
    cout << "Enter the number of memory blocks: ";
    cin >> m;
    vector<int> v2(m);

    cout << "Enter the memory block sizes: ";
    for (int i = 0; i < m; i++)
    {
        cin >> v2[i];
    }

    next_fit(v1, v2);
    return 0;
}